#ifndef _MOVIT_VERSION_H
#define _MOVIT_VERSION_H 1

// A number that will increase every time the visible user API
// changes, even within git versions. There is no specific version
// documentation outside the regular changelogs, though.

#define MOVIT_VERSION 30

#endif // !defined(_MOVIT_VERSION_H)
